/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;
/**
 *
 * @author Mani
 */
public class Login extends HttpServlet 
{
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter())
        {
            
            String username=request.getParameter("username");
            String password=request.getParameter("password");
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection cn;
            cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/todo?zeroDateTimeBehavior=convertToNull","root","");
            Statement st;
            st=cn.createStatement();
            String sql="select * from users where Username='"+username+"'and Password='"+password+"'";
            ResultSet rs=st.executeQuery(sql);
            if(rs.next())
            {
                HttpSession session = request.getSession(true);
                session.setAttribute("uname", username);
                session.setAttribute("pass",password);
                session.setMaxInactiveInterval(30);
                response.sendRedirect("todolist.jsp");
            }
            else
            {
                RequestDispatcher rd=request.getRequestDispatcher("/index.html");  
                out.println("<font color=red>Either user name or password is wrong.</font>");
                rd.include(request, response);
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

//INSERT INTO `users` (`Id`, `Username`, `Password`) VALUES ('1', 'DloadMani', '258456');
//CREATE TABLE `todo`.`users` ( `Id` INT(10) NULL AUTO_INCREMENT ,  `Username` VARCHAR(30) NOT NULL ,  `Password` VARCHAR(30) NOT NULL ,    PRIMARY KEY  (`Id`)) ENGINE = InnoDB;
